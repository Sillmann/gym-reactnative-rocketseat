export type UserDTO = {
  id: string;
  name: string;
  email: string;
  avatar: string;
}