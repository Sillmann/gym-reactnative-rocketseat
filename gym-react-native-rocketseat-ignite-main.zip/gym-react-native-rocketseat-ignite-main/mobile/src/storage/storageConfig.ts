const USER_STORAGE = '@gymignite:user';
export { USER_STORAGE };